
██╗░░░░░███╗░░██╗██╗░░██╗
██║░░░░░████╗░██║██║░██╔╝
██║░░░░░██╔██╗██║█████═╝░
██║░░░░░██║╚████║██╔═██╗░
███████╗██║░╚███║██║░╚██╗
╚══════╝╚═╝░░╚══╝╚═╝░░╚═╝
My new piece of malware, written in C++. 
I take no responsibility for any damage caused;
run it at your own risk.
It is recommended to use a virtual machine with a pre-prepared snapshot.